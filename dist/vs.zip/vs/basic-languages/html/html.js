'use strict';
/*!-----------------------------------------------------------------------------
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Version: 0.38.0(0e330ae453813de4e6cf272460fb79c7117073d0)
 * Released under the MIT license
 * https://github.com/microsoft/monaco-editor/blob/main/LICENSE.txt
 *-----------------------------------------------------------------------------*/
define('vs/basic-languages/html/html', ['require', 'require'], (require) => {
  var moduleExports = (() => {
    var u = Object.create;
    var a = Object.defineProperty;
    var b = Object.getOwnPropertyDescriptor;
    var x = Object.getOwnPropertyNames;
    var y = Object.getPrototypeOf,
      g = Object.prototype.hasOwnProperty;
    var k = ((e) =>
      typeof require != 'undefined'
        ? require
        : typeof Proxy != 'undefined'
        ? new Proxy(e, {
            get: (t, n) => (typeof require != 'undefined' ? require : t)[n],
          })
        : e)(function (e) {
      if (typeof require != 'undefined') return require.apply(this, arguments);
      throw new Error('Dynamic require of "' + e + '" is not supported');
    });
    var E = (e, t) => () => (
        t || e((t = { exports: {} }).exports, t), t.exports
      ),
      T = (e, t) => {
        for (var n in t) a(e, n, { get: t[n], enumerable: !0 });
      },
      o = (e, t, n, s) => {
        if ((t && typeof t == 'object') || typeof t == 'function')
          for (let r of x(t))
            !g.call(e, r) &&
              r !== n &&
              a(e, r, {
                get: () => t[r],
                enumerable: !(s = b(t, r)) || s.enumerable,
              });
        return e;
      },
      d = (e, t, n) => (o(e, t, 'default'), n && o(n, t, 'default')),
      m = (e, t, n) => (
        (n = e != null ? u(y(e)) : {}),
        o(
          t || !e || !e.__esModule
            ? a(n, 'default', { value: e, enumerable: !0 })
            : n,
          e,
        )
      ),
      w = (e) => o(a({}, '__esModule', { value: !0 }), e);
    var l = E((A, p) => {
      var h = m(k('vs/editor/editor.api'));
      p.exports = h;
    });
    var $ = {};
    T($, { conf: () => v, language: () => f });
    var i = {};
    d(i, m(l()));
    var c = [
        'area',
        'base',
        'br',
        'col',
        'embed',
        'hr',
        'img',
        'input',
        'keygen',
        'link',
        'menuitem',
        'meta',
        'param',
        'source',
        'track',
        'wbr',
      ],
      v = {
        wordPattern:
          /(-?\d*\.\d\w*)|([^\`\~\!\@\$\^\&\*\(\)\=\+\[\{\]\}\\\|\;\:\'\"\,\.\<\>\/\s]+)/g,
        comments: { blockComment: ['<!--', '-->'] },
        brackets: [
          ['<!--', '-->'],
          ['<', '>'],
          ['{', '}'],
          ['(', ')'],
        ],
        autoClosingPairs: [
          { open: '{', close: '}' },
          { open: '[', close: ']' },
          { open: '(', close: ')' },
          { open: '"', close: '"' },
          { open: "'", close: "'" },
        ],
        surroundingPairs: [
          { open: '"', close: '"' },
          { open: "'", close: "'" },
          { open: '{', close: '}' },
          { open: '[', close: ']' },
          { open: '(', close: ')' },
          { open: '<', close: '>' },
        ],
        onEnterRules: [
          {
            beforeText: new RegExp(
              `<(?!(?:${c.join(
                '|',
              )}))([_:\\w][_:\\w-.\\d]*)([^/>]*(?!/)>)[^<]*$`,
              'i',
            ),
            afterText: /^<\/([_:\w][_:\w-.\d]*)\s*>$/i,
            action: { indentAction: i.languages.IndentAction.IndentOutdent },
          },
          {
            beforeText: new RegExp(
              `<(?!(?:${c.join('|')}))(\\w[\\w\\d]*)([^/>]*(?!/)>)[^<]*$`,
              'i',
            ),
            action: { indentAction: i.languages.IndentAction.Indent },
          },
        ],
        folding: {
          markers: {
            start: new RegExp('^\\s*<!--\\s*#region\\b.*-->'),
            end: new RegExp('^\\s*<!--\\s*#endregion\\b.*-->'),
          },
        },
      },
      f = {
        defaultToken: '',
        tokenPostfix: '.html',
        ignoreCase: !0,
        tokenizer: {
          root: [
            [/<!DOCTYPE/, 'metatag', '@doctype'],
            [/<!--/, 'comment', '@comment'],
            [
              /(<)((?:[\w\-]+:)?[\w\-]+)(\s*)(\/>)/,
              ['delimiter', 'tag', '', 'delimiter'],
            ],
            [/(<)(script)/, ['delimiter', { token: 'tag', next: '@script' }]],
            [/(<)(style)/, ['delimiter', { token: 'tag', next: '@style' }]],
            [
              /(<)((?:[\w\-]+:)?[\w\-]+)/,
              ['delimiter', { token: 'tag', next: '@otherTag' }],
            ],
            [
              /(<\/)((?:[\w\-]+:)?[\w\-]+)/,
              ['delimiter', { token: 'tag', next: '@otherTag' }],
            ],
            [/</, 'delimiter'],
            [/[^<]+/],
          ],
          doctype: [
            [/[^>]+/, 'metatag.content'],
            [/>/, 'metatag', '@pop'],
          ],
          comment: [
            [/-->/, 'comment', '@pop'],
            [/[^-]+/, 'comment.content'],
            [/./, 'comment.content'],
          ],
          otherTag: [
            [/\/?>/, 'delimiter', '@pop'],
            [/"([^"]*)"/, 'attribute.value'],
            [/'([^']*)'/, 'attribute.value'],
            [/[\w\-]+/, 'attribute.name'],
            [/=/, 'delimiter'],
            [/[ \t\r\n]+/],
          ],
          script: [
            [/type/, 'attribute.name', '@scriptAfterType'],
            [/"([^"]*)"/, 'attribute.value'],
            [/'([^']*)'/, 'attribute.value'],
            [/[\w\-]+/, 'attribute.name'],
            [/=/, 'delimiter'],
            [
              />/,
              {
                token: 'delimiter',
                next: '@scriptEmbedded',
                nextEmbedded: 'text/javascript',
              },
            ],
            [/[ \t\r\n]+/],
            [
              /(<\/)(script\s*)(>)/,
              ['delimiter', 'tag', { token: 'delimiter', next: '@pop' }],
            ],
          ],
          scriptAfterType: [
            [/=/, 'delimiter', '@scriptAfterTypeEquals'],
            [
              />/,
              {
                token: 'delimiter',
                next: '@scriptEmbedded',
                nextEmbedded: 'text/javascript',
              },
            ],
            [/[ \t\r\n]+/],
            [/<\/script\s*>/, { token: '@rematch', next: '@pop' }],
          ],
          scriptAfterTypeEquals: [
            [
              /"module"/,
              {
                token: 'attribute.value',
                switchTo: '@scriptWithCustomType.text/javascript',
              },
            ],
            [
              /'module'/,
              {
                token: 'attribute.value',
                switchTo: '@scriptWithCustomType.text/javascript',
              },
            ],
            [
              /"([^"]*)"/,
              {
                token: 'attribute.value',
                switchTo: '@scriptWithCustomType.$1',
              },
            ],
            [
              /'([^']*)'/,
              {
                token: 'attribute.value',
                switchTo: '@scriptWithCustomType.$1',
              },
            ],
            [
              />/,
              {
                token: 'delimiter',
                next: '@scriptEmbedded',
                nextEmbedded: 'text/javascript',
              },
            ],
            [/[ \t\r\n]+/],
            [/<\/script\s*>/, { token: '@rematch', next: '@pop' }],
          ],
          scriptWithCustomType: [
            [
              />/,
              {
                token: 'delimiter',
                next: '@scriptEmbedded.$S2',
                nextEmbedded: '$S2',
              },
            ],
            [/"([^"]*)"/, 'attribute.value'],
            [/'([^']*)'/, 'attribute.value'],
            [/[\w\-]+/, 'attribute.name'],
            [/=/, 'delimiter'],
            [/[ \t\r\n]+/],
            [/<\/script\s*>/, { token: '@rematch', next: '@pop' }],
          ],
          scriptEmbedded: [
            [
              /<\/script/,
              { token: '@rematch', next: '@pop', nextEmbedded: '@pop' },
            ],
            [/[^<]+/, ''],
          ],
          style: [
            [/type/, 'attribute.name', '@styleAfterType'],
            [/"([^"]*)"/, 'attribute.value'],
            [/'([^']*)'/, 'attribute.value'],
            [/[\w\-]+/, 'attribute.name'],
            [/=/, 'delimiter'],
            [
              />/,
              {
                token: 'delimiter',
                next: '@styleEmbedded',
                nextEmbedded: 'text/css',
              },
            ],
            [/[ \t\r\n]+/],
            [
              /(<\/)(style\s*)(>)/,
              ['delimiter', 'tag', { token: 'delimiter', next: '@pop' }],
            ],
          ],
          styleAfterType: [
            [/=/, 'delimiter', '@styleAfterTypeEquals'],
            [
              />/,
              {
                token: 'delimiter',
                next: '@styleEmbedded',
                nextEmbedded: 'text/css',
              },
            ],
            [/[ \t\r\n]+/],
            [/<\/style\s*>/, { token: '@rematch', next: '@pop' }],
          ],
          styleAfterTypeEquals: [
            [
              /"([^"]*)"/,
              { token: 'attribute.value', switchTo: '@styleWithCustomType.$1' },
            ],
            [
              /'([^']*)'/,
              { token: 'attribute.value', switchTo: '@styleWithCustomType.$1' },
            ],
            [
              />/,
              {
                token: 'delimiter',
                next: '@styleEmbedded',
                nextEmbedded: 'text/css',
              },
            ],
            [/[ \t\r\n]+/],
            [/<\/style\s*>/, { token: '@rematch', next: '@pop' }],
          ],
          styleWithCustomType: [
            [
              />/,
              {
                token: 'delimiter',
                next: '@styleEmbedded.$S2',
                nextEmbedded: '$S2',
              },
            ],
            [/"([^"]*)"/, 'attribute.value'],
            [/'([^']*)'/, 'attribute.value'],
            [/[\w\-]+/, 'attribute.name'],
            [/=/, 'delimiter'],
            [/[ \t\r\n]+/],
            [/<\/style\s*>/, { token: '@rematch', next: '@pop' }],
          ],
          styleEmbedded: [
            [
              /<\/style/,
              { token: '@rematch', next: '@pop', nextEmbedded: '@pop' },
            ],
            [/[^<]+/, ''],
          ],
        },
      };
    return w($);
  })();
  return moduleExports;
});
