'use strict';
/*!-----------------------------------------------------------------------------
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Version: 0.38.0(0e330ae453813de4e6cf272460fb79c7117073d0)
 * Released under the MIT license
 * https://github.com/microsoft/monaco-editor/blob/main/LICENSE.txt
 *-----------------------------------------------------------------------------*/
define('vs/basic-languages/pla/pla', ['require', 'require'], (require) => {
  var moduleExports = (() => {
    var s = Object.defineProperty;
    var a = Object.getOwnPropertyDescriptor;
    var r = Object.getOwnPropertyNames;
    var p = Object.prototype.hasOwnProperty;
    var l = (o, e) => {
        for (var n in e) s(o, n, { get: e[n], enumerable: !0 });
      },
      c = (o, e, n, i) => {
        if ((e && typeof e == 'object') || typeof e == 'function')
          for (let t of r(e))
            !p.call(o, t) &&
              t !== n &&
              s(o, t, {
                get: () => e[t],
                enumerable: !(i = a(e, t)) || i.enumerable,
              });
        return o;
      };
    var d = (o) => c(s({}, '__esModule', { value: !0 }), o);
    var u = {};
    l(u, { conf: () => k, language: () => m });
    var k = {
        comments: { lineComment: '#' },
        brackets: [
          ['[', ']'],
          ['<', '>'],
          ['(', ')'],
        ],
        autoClosingPairs: [
          { open: '[', close: ']' },
          { open: '<', close: '>' },
          { open: '(', close: ')' },
        ],
        surroundingPairs: [
          { open: '[', close: ']' },
          { open: '<', close: '>' },
          { open: '(', close: ')' },
        ],
      },
      m = {
        defaultToken: '',
        tokenPostfix: '.pla',
        brackets: [
          { open: '[', close: ']', token: 'delimiter.square' },
          { open: '<', close: '>', token: 'delimiter.angle' },
          { open: '(', close: ')', token: 'delimiter.parenthesis' },
        ],
        keywords: [
          '.i',
          '.o',
          '.mv',
          '.ilb',
          '.ob',
          '.label',
          '.type',
          '.phase',
          '.pair',
          '.symbolic',
          '.symbolic-output',
          '.kiss',
          '.p',
          '.e',
          '.end',
        ],
        comment: /#.*$/,
        identifier: /[a-zA-Z]+[a-zA-Z0-9_\-]*/,
        plaContent: /[01\-~\|]+/,
        tokenizer: {
          root: [
            { include: '@whitespace' },
            [/@comment/, 'comment'],
            [
              /\.([a-zA-Z_\-]+)/,
              {
                cases: {
                  '@eos': { token: 'keyword.$1' },
                  '@keywords': {
                    cases: {
                      '.type': { token: 'keyword.$1', next: '@type' },
                      '@default': { token: 'keyword.$1', next: '@keywordArg' },
                    },
                  },
                  '@default': { token: 'keyword.$1' },
                },
              },
            ],
            [/@identifier/, 'identifier'],
            [/@plaContent/, 'string'],
          ],
          whitespace: [[/[ \t\r\n]+/, '']],
          type: [
            { include: '@whitespace' },
            [/\w+/, { token: 'type', next: '@pop' }],
          ],
          keywordArg: [
            [
              /[ \t\r\n]+/,
              {
                cases: { '@eos': { token: '', next: '@pop' }, '@default': '' },
              },
            ],
            [/@comment/, 'comment', '@pop'],
            [
              /[<>()\[\]]/,
              {
                cases: {
                  '@eos': { token: '@brackets', next: '@pop' },
                  '@default': '@brackets',
                },
              },
            ],
            [
              /\-?\d+/,
              {
                cases: {
                  '@eos': { token: 'number', next: '@pop' },
                  '@default': 'number',
                },
              },
            ],
            [
              /@identifier/,
              {
                cases: {
                  '@eos': { token: 'identifier', next: '@pop' },
                  '@default': 'identifier',
                },
              },
            ],
            [
              /[;=]/,
              {
                cases: {
                  '@eos': { token: 'delimiter', next: '@pop' },
                  '@default': 'delimiter',
                },
              },
            ],
          ],
        },
      };
    return d(u);
  })();
  return moduleExports;
});
