'use strict';
/*!-----------------------------------------------------------------------------
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Version: 0.38.0(0e330ae453813de4e6cf272460fb79c7117073d0)
 * Released under the MIT license
 * https://github.com/microsoft/monaco-editor/blob/main/LICENSE.txt
 *-----------------------------------------------------------------------------*/
define('vs/basic-languages/graphql/graphql', ['require', 'require'], (
  require,
) => {
  var moduleExports = (() => {
    var s = Object.defineProperty;
    var a = Object.getOwnPropertyDescriptor;
    var i = Object.getOwnPropertyNames;
    var l = Object.prototype.hasOwnProperty;
    var c = (n, e) => {
        for (var t in e) s(n, t, { get: e[t], enumerable: !0 });
      },
      d = (n, e, t, r) => {
        if ((e && typeof e == 'object') || typeof e == 'function')
          for (let o of i(e))
            !l.call(n, o) &&
              o !== t &&
              s(n, o, {
                get: () => e[o],
                enumerable: !(r = a(e, o)) || r.enumerable,
              });
        return n;
      };
    var p = (n) => d(s({}, '__esModule', { value: !0 }), n);
    var u = {};
    c(u, { conf: () => g, language: () => I });
    var g = {
        comments: { lineComment: '#' },
        brackets: [
          ['{', '}'],
          ['[', ']'],
          ['(', ')'],
        ],
        autoClosingPairs: [
          { open: '{', close: '}' },
          { open: '[', close: ']' },
          { open: '(', close: ')' },
          { open: '"""', close: '"""', notIn: ['string', 'comment'] },
          { open: '"', close: '"', notIn: ['string', 'comment'] },
        ],
        surroundingPairs: [
          { open: '{', close: '}' },
          { open: '[', close: ']' },
          { open: '(', close: ')' },
          { open: '"""', close: '"""' },
          { open: '"', close: '"' },
        ],
        folding: { offSide: !0 },
      },
      I = {
        defaultToken: 'invalid',
        tokenPostfix: '.gql',
        keywords: [
          'null',
          'true',
          'false',
          'query',
          'mutation',
          'subscription',
          'extend',
          'schema',
          'directive',
          'scalar',
          'type',
          'interface',
          'union',
          'enum',
          'input',
          'implements',
          'fragment',
          'on',
        ],
        typeKeywords: ['Int', 'Float', 'String', 'Boolean', 'ID'],
        directiveLocations: [
          'SCHEMA',
          'SCALAR',
          'OBJECT',
          'FIELD_DEFINITION',
          'ARGUMENT_DEFINITION',
          'INTERFACE',
          'UNION',
          'ENUM',
          'ENUM_VALUE',
          'INPUT_OBJECT',
          'INPUT_FIELD_DEFINITION',
          'QUERY',
          'MUTATION',
          'SUBSCRIPTION',
          'FIELD',
          'FRAGMENT_DEFINITION',
          'FRAGMENT_SPREAD',
          'INLINE_FRAGMENT',
          'VARIABLE_DEFINITION',
        ],
        operators: ['=', '!', '?', ':', '&', '|'],
        symbols: /[=!?:&|]+/,
        escapes: /\\(?:["\\\/bfnrt]|u[0-9A-Fa-f]{4})/,
        tokenizer: {
          root: [
            [
              /[a-z_][\w$]*/,
              {
                cases: { '@keywords': 'keyword', '@default': 'key.identifier' },
              },
            ],
            [
              /[$][\w$]*/,
              {
                cases: {
                  '@keywords': 'keyword',
                  '@default': 'argument.identifier',
                },
              },
            ],
            [
              /[A-Z][\w\$]*/,
              {
                cases: {
                  '@typeKeywords': 'keyword',
                  '@default': 'type.identifier',
                },
              },
            ],
            { include: '@whitespace' },
            [/[{}()\[\]]/, '@brackets'],
            [
              /@symbols/,
              { cases: { '@operators': 'operator', '@default': '' } },
            ],
            [
              /@\s*[a-zA-Z_\$][\w\$]*/,
              { token: 'annotation', log: 'annotation token: $0' },
            ],
            [/\d*\.\d+([eE][\-+]?\d+)?/, 'number.float'],
            [/0[xX][0-9a-fA-F]+/, 'number.hex'],
            [/\d+/, 'number'],
            [/[;,.]/, 'delimiter'],
            [
              /"""/,
              { token: 'string', next: '@mlstring', nextEmbedded: 'markdown' },
            ],
            [/"([^"\\]|\\.)*$/, 'string.invalid'],
            [/"/, { token: 'string.quote', bracket: '@open', next: '@string' }],
          ],
          mlstring: [
            [/[^"]+/, 'string'],
            ['"""', { token: 'string', next: '@pop', nextEmbedded: '@pop' }],
          ],
          string: [
            [/[^\\"]+/, 'string'],
            [/@escapes/, 'string.escape'],
            [/\\./, 'string.escape.invalid'],
            [/"/, { token: 'string.quote', bracket: '@close', next: '@pop' }],
          ],
          whitespace: [
            [/[ \t\r\n]+/, ''],
            [/#.*$/, 'comment'],
          ],
        },
      };
    return p(u);
  })();
  return moduleExports;
});
